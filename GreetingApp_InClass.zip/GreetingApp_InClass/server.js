const express = require("express");
const app = express();
const port = 3001;

app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
});

app.post("/submit", (req, res) => {
  const name = req.body.name;
  res.redirect(`/greet?name=${name}`);
});

app.get("/greet", (req, res) => {
  const name = req.query.name;

  res.send(`
  <html>
  <head>
  <title>Greeting</title>

  <style>
  body {
    margin: 0;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background: linear-gradient(135deg, #01024a, #2e97ff);
    font-family: 'Times New Roman', Times, serif;
  }

  .container {
    background: linear-gradient(135deg, #2e97ff, #01024a);
    padding: 70px 80px;
    border-radius: 30px;
    text-align: center;
    color: white;
    width: 600px;
    max-width: 90%;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
  }

  h1 {
    font-size: 42px;
    margin-bottom: 20px;
  }

  a {
    display: inline-block;
    width: 100%; /* Matches the button width from index.html */
    box-sizing: border-box; 
    margin-top: 20px;
    padding: 18px;
    background: white;
    color: #333;
    text-decoration: none;
    border-radius: 14px;
    font-size: 16px;
    font-weight: bold;
    transition: 0.2s;
  }

  a:hover {
    transform: scale(1.03);
  }
  </style>

  </head>

  <body>
    <div class="container">
      <h1>Hello, ${name}! 👋</h1>
      <a href="/">Go Back</a>
    </div>
  </body>
  </html>
  `);
});

app.listen(port, () => {
  console.log("Server running on http://localhost:3001");
});